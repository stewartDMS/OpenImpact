import React from "react";

const PremiumModal = ({ open, onClose, onUpgrade }) => {
  if (!open) return null;
  return (
    <div className="fixed inset-0 z-50 modal-backdrop flex items-center justify-center p-4 bg-black/50">
      <div className="bg-white rounded-2xl shadow-2xl max-w-4xl w-full max-h-[90vh] overflow-y-auto slide-in">
        <div className="p-8">
          <div className="text-center mb-8">
            <div className="w-20 h-20 bg-gradient-to-r from-yellow-400 to-orange-500 rounded-full flex items-center justify-center mx-auto mb-4">
              <span className="text-white font-bold text-3xl">⭐</span>
            </div>
            <h2 className="text-3xl font-bold text-gray-800 mb-2">Upgrade to Premium</h2>
            <p className="text-xl text-gray-600">Unlock advanced insights and AI-powered analytics</p>
          </div>
          <div className="grid md:grid-cols-3 gap-6 mb-8">
            {/* Free Plan */}
            <PlanCard
              name="Free"
              color="gray"
              price="$0"
              perks={[
                "Basic dashboard access",
                "Company search",
                "Basic ESG scores",
                "No AI insights",
                "No custom reports",
                "No API access"
              ]}
              current
            />
            {/* Pro Plan */}
            <PlanCard
              name="Pro"
              color="impact-blue"
              price="$29"
              perks={[
                "Everything in Free",
                "AI-powered insights",
                "Custom report generation",
                "Advanced analytics",
                "Email alerts",
                "Priority support"
              ]}
              onSelect={() => { if (onUpgrade) onUpgrade("pro"); }}
            />
            {/* Enterprise Plan */}
            <PlanCard
              name="Enterprise"
              color="gray"
              price="$99"
              perks={[
                "Everything in Pro",
                "API access",
                "White-label reports",
                "Custom integrations",
                "Dedicated support",
                "Team collaboration"
              ]}
              onSelect={() => { if (onUpgrade) onUpgrade("enterprise"); }}
            />
          </div>
          <div className="text-center">
            <p className="text-sm text-gray-500 mb-4">All plans include 14-day free trial • Cancel anytime</p>
            <button onClick={onClose} className="text-gray-600 hover:text-gray-800 transition-colors">
              Maybe later
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

const PlanCard = ({ name, color, price, perks, onSelect, current }) => (
  <div className={`border-2 border-${color}-200 rounded-xl p-6`}>
    <div className="text-center mb-6">
      <h3 className="text-xl font-bold text-gray-800">{name}</h3>
      <div className={`text-3xl font-bold text-${color === "gray" ? "gray-900" : color} mt-2`}>{price}</div>
      <div className="text-gray-500">per month</div>
    </div>
    <ul className="space-y-3 text-sm">
      {perks.map(perk => (
        <li key={perk} className="flex items-center">
          {perk.startsWith("No") ? (
            <span className="text-gray-400 mr-2">✗</span>
          ) : (
            <span className="text-green-500 mr-2">✓</span>
          )}
          {perk}
        </li>
      ))}
    </ul>
    {current ? (
      <button className="w-full mt-6 py-2 border border-gray-300 rounded-lg text-gray-600 cursor-not-allowed">Current Plan</button>
    ) : (
      <button
        className={`w-full mt-6 py-2 bg-${color} text-white rounded-lg hover:bg-blue-700 transition-colors`}
        onClick={onSelect}
      >
        Upgrade to {name}
      </button>
    )}
  </div>
);

export default PremiumModal;