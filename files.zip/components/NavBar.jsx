import React from "react";
import { useAuth } from "../context/AuthContext";

const NavBar = ({ onOpenCompanySearch, onOpenPremium }) => {
  const { user, openAuthModal, openSidebar } = useAuth();

  return (
    <nav className="bg-white shadow-lg fixed w-full z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-gradient-to-r from-impact-blue to-impact-green rounded-lg flex items-center justify-center">
              <span className="text-white font-bold text-lg">OI</span>
            </div>
            <span className="text-xl font-bold text-gray-800">Open Impact</span>
          </div>
          {!user && (
            <div className="hidden md:flex space-x-8">
              <a href="#features" className="text-gray-600 hover:text-impact-blue transition-colors">Features</a>
              <a href="#dashboard" className="text-gray-600 hover:text-impact-blue transition-colors">Dashboard</a>
              <a href="#api" className="text-gray-600 hover:text-impact-blue transition-colors">API</a>
              <a href="#pricing" className="text-gray-600 hover:text-impact-blue transition-colors">Pricing</a>
            </div>
          )}
          <div className="flex space-x-3">
            {!user ? (
              <div className="flex space-x-3">
                <button className="px-4 py-2 text-impact-blue border border-impact-blue rounded-lg hover:bg-impact-blue hover:text-white transition-colors"
                        onClick={() => openAuthModal("signIn")}>
                  Sign In
                </button>
                <button className="px-4 py-2 bg-impact-blue text-white rounded-lg hover:bg-blue-700 transition-colors"
                        onClick={() => openAuthModal("accountType")}>
                  Get Started
                </button>
              </div>
            ) : (
              <div className="flex items-center space-x-4">
                <button className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
                        onClick={openSidebar}>
                  <svg className="w-6 h-6 text-gray-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 6h16M4 12h16M4 18h16"/>
                  </svg>
                </button>
                <button className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
                        onClick={onOpenCompanySearch}
                        title="Search Companies">
                  <svg className="w-6 h-6 text-impact-blue" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <circle cx="11" cy="11" r="6" stroke="currentColor" strokeWidth="2"/>
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M21 21l-4.35-4.35"/>
                  </svg>
                </button>
                <button className="p-2 hover:bg-yellow-100 rounded-lg transition-colors"
                        onClick={onOpenPremium}
                        title="Upgrade">
                  <span className="text-yellow-500 text-xl">★</span>
                </button>
                <div className="flex items-center space-x-2 px-3 py-2 bg-gray-100 rounded-lg">
                  <div className="w-8 h-8 bg-impact-blue rounded-full flex items-center justify-center text-white text-sm font-bold">
                    {user.avatar}
                  </div>
                  <span className="text-gray-800 font-medium">{user.firstName}</span>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </nav>
  );
};

export default NavBar;