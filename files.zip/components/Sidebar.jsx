import React from "react";
import { useAuth } from "../context/AuthContext";

const Sidebar = ({ onOpenCompanySearch, onOpenPremium }) => {
  const { user, sidebarOpen, closeSidebar, signOut } = useAuth();

  return (
    <>
      <div
        className={`fixed left-0 top-16 h-full w-80 bg-white shadow-2xl transform ${
          sidebarOpen ? "translate-x-0" : "-translate-x-full"
        } transition-transform duration-300 ease-in-out z-40 border-r border-gray-200`}
      >
        <div className="flex flex-col h-full">
          {/* Sidebar Header */}
          <div className="p-6 border-b border-gray-200">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <div className="w-12 h-12 bg-impact-blue rounded-full flex items-center justify-center text-white font-bold text-lg">
                  {user?.avatar}
                </div>
                <div>
                  <h3 className="font-semibold text-gray-800">{user?.firstName} {user?.lastName}</h3>
                  <p className="text-sm text-gray-500">{user?.plan ? user.plan.charAt(0).toUpperCase() + user.plan.slice(1) : "Free Plan"}</p>
                </div>
              </div>
              <button className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
                      onClick={closeSidebar}>
                <svg className="w-5 h-5 text-gray-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12"/>
                </svg>
              </button>
            </div>
          </div>
          {/* Navigation */}
          <nav className="flex-1 p-6 space-y-2">
            <button
              className="w-full flex items-center space-x-3 px-4 py-3 rounded-lg hover:bg-blue-50 transition-colors group"
              onClick={onOpenCompanySearch}
            >
              <div className="w-8 h-8 bg-impact-blue/10 rounded-lg flex items-center justify-center group-hover:bg-impact-blue/20 transition-colors">
                <span className="text-impact-blue text-lg">🔍</span>
              </div>
              <span className="font-medium text-gray-800">Search Companies</span>
            </button>
            <button
              className="w-full flex items-center space-x-3 px-4 py-3 rounded-lg hover:bg-yellow-50 transition-colors group"
              onClick={onOpenPremium}
            >
              <div className="w-8 h-8 bg-yellow-100 rounded-lg flex items-center justify-center group-hover:bg-yellow-200 transition-colors">
                <span className="text-yellow-500 text-lg">★</span>
              </div>
              <span className="font-medium text-yellow-600">Upgrade</span>
            </button>
          </nav>
          {/* Sign Out */}
          <div className="border-t border-gray-200 p-4 mt-auto">
            <button
              className="w-full flex items-center space-x-3 px-4 py-3 text-left rounded-lg hover:bg-red-50 transition-colors group"
              onClick={signOut}
            >
              <div className="w-8 h-8 bg-red-100 rounded-lg flex items-center justify-center group-hover:bg-red-200 transition-colors">
                <span className="text-red-600 text-lg">🚪</span>
              </div>
              <div>
                <p className="font-medium text-red-600">Sign Out</p>
                <p className="text-sm text-red-400">End your session</p>
              </div>
            </button>
          </div>
        </div>
      </div>
      {/* Overlay */}
      {sidebarOpen && (
        <div
          className="fixed inset-0 bg-black bg-opacity-50 z-30"
          onClick={closeSidebar}
          aria-label="Sidebar overlay"
        />
      )}
    </>
  );
};

export default Sidebar;