import React from "react";
import { useAuth } from "../../context/AuthContext";

const AccountTypeForm = () => {
  const { openAuthModal } = useAuth();

  return (
    <div className="p-8">
      <h2 className="text-2xl font-bold text-gray-800 mb-6">Get Started</h2>
      <p className="text-gray-600 mb-8">Select your account type to continue:</p>
      <div className="grid gap-6">
        <button
          className="w-full border-2 border-impact-blue rounded-xl p-5 flex items-center space-x-6 hover:bg-blue-50 transition-colors"
          onClick={() => openAuthModal("signUpGeneral")}
        >
          <span className="text-3xl text-impact-blue">👤</span>
          <div className="text-left">
            <div className="text-lg font-semibold text-impact-blue">Individual / Analyst</div>
            <div className="text-gray-500 text-sm">For investors, students, researchers, and the public</div>
          </div>
        </button>
        <button
          className="w-full border-2 border-green-400 rounded-xl p-5 flex items-center space-x-6 hover:bg-green-50 transition-colors"
          onClick={() => openAuthModal("signUpCompany")}
        >
          <span className="text-3xl text-impact-green">🏢</span>
          <div className="text-left">
            <div className="text-lg font-semibold text-impact-green">Company / Organization</div>
            <div className="text-gray-500 text-sm">For company reps, ESG managers, partners, or data API users</div>
          </div>
        </button>
        <div className="text-center text-gray-500 mt-4">
          Already have an account?{" "}
          <button className="underline text-impact-blue" onClick={() => openAuthModal("signIn")}>
            Sign in
          </button>
        </div>
      </div>
    </div>
  );
};

export default AccountTypeForm;