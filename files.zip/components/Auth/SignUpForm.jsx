import React, { useState } from "react";
import { useAuth } from "../../context/AuthContext";

const SignUpForm = () => {
  const { signUpGeneral, openAuthModal, error } = useAuth();
  const [form, setForm] = useState({
    firstName: "",
    lastName: "",
    email: "",
    password: "",
    organization: ""
  });

  const onSubmit = e => {
    e.preventDefault();
    signUpGeneral(form);
  };

  return (
    <form className="p-8" onSubmit={onSubmit}>
      <h2 className="text-2xl font-bold text-gray-800 mb-6">Sign Up (Individual)</h2>
      <div className="mb-4">
        <label className="block text-gray-700 mb-2">First Name</label>
        <input
          required
          value={form.firstName}
          onChange={e => setForm(f => ({ ...f, firstName: e.target.value }))}
          className="w-full border border-gray-300 rounded-lg px-4 py-2"
        />
      </div>
      <div className="mb-4">
        <label className="block text-gray-700 mb-2">Last Name</label>
        <input
          required
          value={form.lastName}
          onChange={e => setForm(f => ({ ...f, lastName: e.target.value }))}
          className="w-full border border-gray-300 rounded-lg px-4 py-2"
        />
      </div>
      <div className="mb-4">
        <label className="block text-gray-700 mb-2">Email</label>
        <input
          type="email"
          required
          value={form.email}
          onChange={e => setForm(f => ({ ...f, email: e.target.value }))}
          className="w-full border border-gray-300 rounded-lg px-4 py-2"
        />
      </div>
      <div className="mb-4">
        <label className="block text-gray-700 mb-2">Password</label>
        <input
          type="password"
          required
          value={form.password}
          onChange={e => setForm(f => ({ ...f, password: e.target.value }))}
          className="w-full border border-gray-300 rounded-lg px-4 py-2"
        />
      </div>
      <div className="mb-6">
        <label className="block text-gray-700 mb-2">Organization (optional)</label>
        <input
          value={form.organization}
          onChange={e => setForm(f => ({ ...f, organization: e.target.value }))}
          className="w-full border border-gray-300 rounded-lg px-4 py-2"
        />
      </div>
      {error && <div className="text-red-600 mb-4">{error}</div>}
      <button
        type="submit"
        className="w-full bg-impact-blue text-white py-3 rounded-lg font-semibold hover:bg-blue-700 transition-colors"
      >
        Create Account
      </button>
      <div className="text-center text-gray-500 mt-4">
        Already have an account?{" "}
        <button className="underline text-impact-blue" onClick={() => openAuthModal("signIn")} type="button">
          Sign in
        </button>
      </div>
    </form>
  );
};

export default SignUpForm;