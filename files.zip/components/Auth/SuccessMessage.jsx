import React from "react";

const SuccessMessage = ({ message, onClose }) => (
  <div className="fixed inset-0 z-50 modal-backdrop flex items-center justify-center p-4 bg-black/30">
    <div className="bg-white rounded-2xl shadow-2xl max-w-md w-full p-8 flex flex-col items-center">
      <div className="w-20 h-20 bg-gradient-to-r from-green-400 to-impact-green rounded-full flex items-center justify-center mb-4">
        <span className="text-white font-bold text-4xl">✓</span>
      </div>
      <h2 className="text-2xl font-semibold text-impact-green mb-2">Success!</h2>
      <p className="text-gray-700 mb-6">{message}</p>
      <button
        onClick={onClose}
        className="bg-impact-green text-white px-8 py-3 rounded-lg font-semibold hover:bg-green-700 transition-colors"
      >
        Continue
      </button>
    </div>
  </div>
);

export default SuccessMessage;