import React from "react";
import { useAuth } from "../../context/AuthContext";

const UserDashboardPage = () => {
  const { user } = useAuth();

  return (
    <div className="max-w-5xl mx-auto py-24 px-4">
      <h1 className="text-3xl font-bold mb-4">Welcome, {user?.firstName || "User"}!</h1>
      <p className="text-gray-700 mb-8">
        This is your personalized dashboard. Here you can search for companies, analyze ESG scores, and access AI-powered insights.
      </p>
      <div className="grid md:grid-cols-3 gap-6">
        <div className="bg-white rounded-xl shadow p-6 card-hover">
          <div className="text-impact-blue text-4xl mb-4">🔍</div>
          <div className="font-semibold text-lg mb-2">Search Companies</div>
          <p className="text-gray-600 text-sm">Find any company and view their ESG performance and impact scores.</p>
        </div>
        <div className="bg-white rounded-xl shadow p-6 card-hover">
          <div className="text-impact-green text-4xl mb-4">📊</div>
          <div className="font-semibold text-lg mb-2">Analyze ESG Metrics</div>
          <p className="text-gray-600 text-sm">Get detailed breakdowns and trends for environmental, social, and governance factors.</p>
        </div>
        <div className="bg-white rounded-xl shadow p-6 card-hover">
          <div className="text-impact-purple text-4xl mb-4">🤖</div>
          <div className="font-semibold text-lg mb-2">AI Insights</div>
          <p className="text-gray-600 text-sm">Unlock AI-powered commentary and recommendations (premium).</p>
        </div>
      </div>
    </div>
  );
};

export default UserDashboardPage;