import React from "react";
import { useAuth } from "../context/AuthContext";
import AccountTypeForm from "./Auth/AccountTypeForm";
import SignInForm from "./Auth/SignInForm";
import SignUpForm from "./Auth/SignUpForm";
import CompanySignUpForm from "./Auth/CompanySignUpForm";
import SuccessMessage from "./Auth/SuccessMessage";

const ModalContainer = () => {
  const { modal, closeAuthModal, success, clearSuccess } = useAuth();

  if (!modal && !success) return null;

  return (
    <>
      {modal && (
        <div className="fixed inset-0 z-50 modal-backdrop flex items-center justify-center p-4 bg-black/50">
          <div className="bg-white rounded-2xl shadow-2xl max-w-md w-full p-0 relative">
            <button
              className="absolute top-4 right-4 text-gray-400 hover:text-gray-600 transition-colors"
              onClick={closeAuthModal}
            >
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12"/>
              </svg>
            </button>
            {modal === "accountType" && <AccountTypeForm />}
            {modal === "signIn" && <SignInForm />}
            {modal === "signUpGeneral" && <SignUpForm />}
            {modal === "signUpCompany" && <CompanySignUpForm />}
          </div>
        </div>
      )}
      {success && <SuccessMessage message={success} onClose={clearSuccess} />}
    </>
  );
};

export default ModalContainer;