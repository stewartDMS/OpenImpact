import React, { useState } from "react";

const DUMMY_COMPANIES = [
  { name: 'Tesla, Inc.', ticker: 'TSLA', sector: 'Electric Vehicles', esg: 8.4, logo: 'T' },
  { name: 'Apple Inc.', ticker: 'AAPL', sector: 'Technology', esg: 8.1, logo: 'A' },
  { name: 'Microsoft Corporation', ticker: 'MSFT', sector: 'Technology', esg: 8.7, logo: 'M' },
  { name: 'Amazon.com Inc.', ticker: 'AMZN', sector: 'E-commerce', esg: 7.2, logo: 'A' },
  { name: 'Alphabet Inc.', ticker: 'GOOGL', sector: 'Technology', esg: 7.8, logo: 'G' },
  { name: 'Johnson & Johnson', ticker: 'JNJ', sector: 'Healthcare', esg: 8.9, logo: 'J' },
  { name: 'Procter & Gamble', ticker: 'PG', sector: 'Consumer Goods', esg: 8.3, logo: 'P' },
  { name: 'Coca-Cola Company', ticker: 'KO', sector: 'Beverages', esg: 7.6, logo: 'C' },
  { name: 'Nike Inc.', ticker: 'NKE', sector: 'Apparel', esg: 7.9, logo: 'N' },
  { name: 'Walmart Inc.', ticker: 'WMT', sector: 'Retail', esg: 7.4, logo: 'W' },
];

const CompanySearchModal = ({ open, onClose, onSelect }) => {
  const [query, setQuery] = useState("");

  const filteredCompanies =
    !query
      ? DUMMY_COMPANIES
      : DUMMY_COMPANIES.filter(company =>
          company.name.toLowerCase().includes(query.toLowerCase()) ||
          company.ticker.toLowerCase().includes(query.toLowerCase()) ||
          company.sector.toLowerCase().includes(query.toLowerCase())
        );

  if (!open) return null;

  return (
    <div className="fixed inset-0 z-50 modal-backdrop flex items-center justify-center p-4 bg-black/50">
      <div className="bg-white rounded-2xl shadow-2xl max-w-4xl w-full max-h-[90vh] overflow-hidden slide-in">
        <div className="p-6 border-b flex justify-between items-center">
          <h2 className="text-2xl font-bold text-gray-800">Search Companies</h2>
          <button onClick={onClose} className="text-gray-400 hover:text-gray-600 transition-colors">
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12"/>
            </svg>
          </button>
        </div>
        <div className="p-6">
          <input
            type="text"
            placeholder="Search by company name, ticker, or industry..."
            className="w-full px-4 py-3 mb-4 border border-gray-300 rounded-lg"
            value={query}
            onChange={e => setQuery(e.target.value)}
            autoFocus
          />
          <div className="space-y-3 max-h-80 overflow-y-auto">
            {filteredCompanies.map(company => (
              <div
                key={company.ticker}
                className="company-result p-4 border border-gray-200 rounded-lg hover:bg-gray-50 cursor-pointer flex items-center space-x-4"
                onClick={() => { if (onSelect) onSelect(company); }}
              >
                <div className="w-12 h-12 bg-gradient-to-br from-impact-blue to-blue-600 rounded-lg flex items-center justify-center text-white font-bold">
                  {company.logo}
                </div>
                <div className="flex-1">
                  <div className="flex justify-between items-start">
                    <div>
                      <h3 className="font-semibold text-gray-800">{company.name}</h3>
                      <p className="text-sm text-gray-600">{company.ticker} • {company.sector}</p>
                    </div>
                    <div className="text-right">
                      <div className="text-lg font-bold text-impact-blue">{company.esg}</div>
                      <div className="text-xs text-gray-500">ESG Score</div>
                    </div>
                  </div>
                </div>
              </div>
            ))}
            {!filteredCompanies.length && <p className="text-gray-500 text-center">No matching companies found.</p>}
          </div>
        </div>
      </div>
    </div>
  );
};

export default CompanySearchModal;