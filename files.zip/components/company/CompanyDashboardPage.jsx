import React from "react";
import { useAuth } from "../../context/AuthContext";

const CompanyDashboardPage = () => {
  const { user } = useAuth();

  return (
    <div className="max-w-5xl mx-auto py-24 px-4">
      <h1 className="text-3xl font-bold mb-4">
        {user?.companyName ? `Welcome, ${user.companyName}!` : "Company Dashboard"}
      </h1>
      <p className="text-gray-700 mb-8">
        This is your company dashboard. Monitor your ESG analytics, manage your public profile, and access API keys.
      </p>
      <div className="grid md:grid-cols-3 gap-6">
        <div className="bg-white rounded-xl shadow p-6 card-hover">
          <div className="text-impact-green text-4xl mb-4">📈</div>
          <div className="font-semibold text-lg mb-2">Your ESG Score</div>
          <p className="text-gray-600 text-sm">
            See how your company ranks and what factors influence your ESG rating.
          </p>
        </div>
        <div className="bg-white rounded-xl shadow p-6 card-hover">
          <div className="text-impact-blue text-4xl mb-4">🔑</div>
          <div className="font-semibold text-lg mb-2">API Key</div>
          <p className="text-gray-600 text-sm">
            Your API key: <span className="font-mono text-xs">{user?.apiKey || "N/A"}</span>
          </p>
        </div>
        <div className="bg-white rounded-xl shadow p-6 card-hover">
          <div className="text-impact-orange text-4xl mb-4">⚙️</div>
          <div className="font-semibold text-lg mb-2">Manage Profile</div>
          <p className="text-gray-600 text-sm">
            Update your company information, logo, and public ESG profile.
          </p>
        </div>
      </div>
    </div>
  );
};

export default CompanyDashboardPage;