import React from "react";

const CompanyProfilePage = ({ selectedCompany }) => {
  // Optionally, selectedCompany can be pulled from global state or router query
  const company = selectedCompany || {
    name: "Tesla, Inc.",
    ticker: "TSLA",
    sector: "Electric Vehicles",
    esg: 8.4,
    logo: "T",
    description: "Tesla is the leader in electric vehicles and clean energy.",
  };

  return (
    <div className="max-w-3xl mx-auto py-24 px-4">
      <div className="flex items-center space-x-6 mb-8">
        <div className="w-20 h-20 bg-gradient-to-br from-impact-blue to-blue-600 rounded-lg flex items-center justify-center text-white font-bold text-4xl">
          {company.logo}
        </div>
        <div>
          <h1 className="text-3xl font-bold">{company.name}</h1>
          <p className="text-gray-600">{company.ticker} • {company.sector}</p>
        </div>
        <div className="ml-auto flex flex-col items-end">
          <span className="text-impact-blue text-2xl font-bold">{company.esg}</span>
          <span className="text-xs text-gray-500">ESG Score</span>
        </div>
      </div>
      <div className="bg-white rounded-xl shadow p-8">
        <h2 className="text-xl font-semibold mb-4">Company Overview</h2>
        <p className="text-gray-700 mb-4">{company.description}</p>
        <div className="grid md:grid-cols-3 gap-6">
          <div className="bg-impact-blue/10 rounded-lg p-6">
            <div className="text-impact-blue text-3xl mb-2">🌱</div>
            <div className="font-semibold mb-1">Environmental</div>
            <div className="text-gray-600 text-sm">Strong emissions reduction, clean energy focus.</div>
          </div>
          <div className="bg-impact-green/10 rounded-lg p-6">
            <div className="text-impact-green text-3xl mb-2">🤝</div>
            <div className="font-semibold mb-1">Social</div>
            <div className="text-gray-600 text-sm">Good labor practices, diversity initiatives, community impact.</div>
          </div>
          <div className="bg-impact-purple/10 rounded-lg p-6">
            <div className="text-impact-purple text-3xl mb-2">🏛️</div>
            <div className="font-semibold mb-1">Governance</div>
            <div className="text-gray-600 text-sm">Transparent leadership, ethical governance structure.</div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CompanyProfilePage;