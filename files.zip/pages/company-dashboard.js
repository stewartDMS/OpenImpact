import React from "react";
import CompanyDashboardPage from "../components/company/CompanyDashboardPage";
import useRequireAuth from "../hooks/useRequireAuth";

export default function CompanyDashboard() {
  useRequireAuth();
  return <CompanyDashboardPage />;
}