import React from "react";
import { useAuth } from "../context/AuthContext";

export default function Home() {
  const { openAuthModal } = useAuth();

  return (
    <main className="min-h-screen flex flex-col items-center justify-center bg-gradient-to-br from-impact-blue to-impact-green py-24 px-4">
      <div className="bg-white rounded-3xl shadow-2xl max-w-2xl w-full p-10 text-center">
        <div className="w-16 h-16 bg-gradient-to-r from-impact-blue to-impact-green rounded-full flex items-center justify-center mx-auto mb-6">
          <span className="text-white font-bold text-3xl">OI</span>
        </div>
        <h1 className="text-4xl font-extrabold text-impact-blue mb-3">Open Impact</h1>
        <p className="text-lg text-gray-700 mb-6">
          The open ESG analytics dashboard for everyone.<br />
          Discover, compare, and analyze company sustainability & impact.
        </p>
        <div className="flex flex-col gap-4">
          <button
            className="bg-impact-blue text-white px-8 py-4 rounded-xl text-lg font-bold hover:bg-blue-700 transition-colors"
            onClick={() => openAuthModal("accountType")}
          >
            Get Started
          </button>
          <button
            className="border border-impact-blue text-impact-blue px-8 py-4 rounded-xl text-lg font-bold hover:bg-blue-50 transition-colors"
            onClick={() => openAuthModal("signIn")}
          >
            Sign In
          </button>
        </div>
      </div>
      <footer className="mt-20 text-gray-400 text-sm">
        &copy; {new Date().getFullYear()} Open Impact. All rights reserved.
      </footer>
    </main>
  );
}