import React from "react";
import UserDashboardPage from "../components/dashboard/UserDashboardPage";
import useRequireAuth from "../hooks/useRequireAuth";

export default function Dashboard() {
  useRequireAuth();
  return <UserDashboardPage />;
}