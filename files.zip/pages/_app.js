import '../styles/globals.css';
import { AuthProvider } from '../context/AuthContext';
import NavBar from '../components/NavBar';
import Sidebar from '../components/Sidebar';
import ModalContainer from '../components/ModalContainer';
import PremiumModal from '../components/PremiumModal';
import CompanySearchModal from '../components/company/CompanySearchModal';
import { useState } from 'react';

function MyApp({ Component, pageProps }) {
  // Modal state for premium and company search
  const [premiumOpen, setPremiumOpen] = useState(false);
  const [companySearchOpen, setCompanySearchOpen] = useState(false);
  const [selectedCompany, setSelectedCompany] = useState(null);

  return (
    <AuthProvider>
      <NavBar
        onOpenCompanySearch={() => setCompanySearchOpen(true)}
        onOpenPremium={() => setPremiumOpen(true)}
      />
      <Sidebar
        onOpenCompanySearch={() => setCompanySearchOpen(true)}
        onOpenPremium={() => setPremiumOpen(true)}
      />
      <ModalContainer />
      <PremiumModal open={premiumOpen} onClose={() => setPremiumOpen(false)} />
      <CompanySearchModal
        open={companySearchOpen}
        onClose={() => setCompanySearchOpen(false)}
        onSelect={company => {
          setSelectedCompany(company);
          setCompanySearchOpen(false);
          // Optionally, route to company profile with query/context
        }}
      />
      <div className="pt-20"> {/* To offset fixed navbar */}
        <Component {...pageProps} selectedCompany={selectedCompany} />
      </div>
    </AuthProvider>
  );
}

export default MyApp;