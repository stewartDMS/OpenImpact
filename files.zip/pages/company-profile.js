import React from "react";
import CompanyProfilePage from "../components/company/CompanyProfilePage";
import useRequireAuth from "../hooks/useRequireAuth";

export default function CompanyProfile({ selectedCompany }) {
  useRequireAuth();
  return <CompanyProfilePage selectedCompany={selectedCompany} />;
}