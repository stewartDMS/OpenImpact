/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./pages/**/*.{js,jsx,ts,tsx}",
    "./components/**/*.{js,jsx,ts,tsx}"
  ],
  theme: {
    extend: {
      colors: {
        'impact-blue': '#0066CC',
        'impact-green': '#00B894',
        'impact-purple': '#6C5CE7',
        'impact-orange': '#FD79A8'
      }
    }
  },
  plugins: []
};