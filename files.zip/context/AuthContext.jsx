import React, { createContext, useContext, useState } from "react";

const USERS_KEY = "openImpactUsers";
const CURRENT_USER_KEY = "openImpactCurrentUser";

const AuthContext = createContext();

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(() => {
    if (typeof window !== "undefined") {
      const saved = localStorage.getItem(CURRENT_USER_KEY);
      return saved ? JSON.parse(saved) : null;
    }
    return null;
  });

  const [modal, setModal] = useState(null);
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");

  const openAuthModal = (which) => {
    setError("");
    setModal(which);
  };
  const closeAuthModal = () => setModal(null);

  const openSidebar = () => setSidebarOpen(true);
  const closeSidebar = () => setSidebarOpen(false);

  const showSuccess = (msg) => setSuccess(msg);
  const clearSuccess = () => setSuccess("");

  const loadUsers = () => {
    if (typeof window === "undefined") return [];
    try {
      return JSON.parse(localStorage.getItem(USERS_KEY)) || [];
    } catch {
      return [];
    }
  };
  const saveUsers = (users) => {
    if (typeof window !== "undefined") {
      localStorage.setItem(USERS_KEY, JSON.stringify(users));
    }
  };

  const signInWithEmail = (email, password) => {
    const users = loadUsers();
    const found = users.find(u => u.email === email && u.password === password);
    if (found) {
      setUser(found);
      localStorage.setItem(CURRENT_USER_KEY, JSON.stringify(found));
      closeAuthModal();
      setError("");
      showSuccess(`Welcome back, ${found.firstName}!`);
    } else {
      setError("Invalid email or password.");
    }
  };

  const signUpGeneral = ({ firstName, lastName, email, password, organization }) => {
    const users = loadUsers();
    if (users.find(u => u.email === email)) {
      setError("An account with this email already exists.");
      return;
    }
    const userObj = {
      id: Date.now().toString(),
      firstName,
      lastName,
      email,
      password,
      organization,
      accountType: "general",
      plan: "free",
      createdAt: new Date().toISOString(),
      avatar: firstName.charAt(0).toUpperCase() + (lastName ? lastName.charAt(0).toUpperCase() : ""),
    };
    users.push(userObj);
    saveUsers(users);
    setUser(userObj);
    localStorage.setItem(CURRENT_USER_KEY, JSON.stringify(userObj));
    closeAuthModal();
    setError("");
    showSuccess(`Welcome to Open Impact, ${firstName}!`);
  };

  const signUpCompany = ({
    firstName, lastName, email, password, companyName, industry, companySize, jobTitle
  }) => {
    const users = loadUsers();
    if (users.find(u => u.email === email)) {
      setError("An account with this email already exists.");
      return;
    }
    const userObj = {
      id: Date.now().toString(),
      firstName,
      lastName,
      email,
      password,
      companyName,
      industry,
      companySize,
      jobTitle,
      accountType: "company",
      plan: "company_starter",
      createdAt: new Date().toISOString(),
      avatar: companyName ? companyName.charAt(0).toUpperCase() : "C",
      apiKey: "oi_" + Math.random().toString(36).substr(2, 9) + "_" + Date.now().toString(36),
    };
    users.push(userObj);
    saveUsers(users);
    setUser(userObj);
    localStorage.setItem(CURRENT_USER_KEY, JSON.stringify(userObj));
    closeAuthModal();
    setError("");
    showSuccess(`Welcome to Open Impact, ${companyName || firstName}!`);
  };

  const signOut = () => {
    setUser(null);
    if (typeof window !== "undefined") localStorage.removeItem(CURRENT_USER_KEY);
    setSuccess("Signed out successfully!");
  };

  return (
    <AuthContext.Provider value={{
      user, signOut,
      modal, openAuthModal, closeAuthModal,
      sidebarOpen, openSidebar, closeSidebar,
      signInWithEmail,
      signUpGeneral,
      signUpCompany,
      error,
      success,
      showSuccess,
      clearSuccess,
    }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => useContext(AuthContext);